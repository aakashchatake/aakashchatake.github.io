# GFIS Springer-style Manuscript Package

This package contains:
- GFIS_Springer_Manuscript_Draft_v01.docx: main Word manuscript draft
- GFIS_Springer_Manuscript_Draft_v01.pdf: PDF render of the manuscript
- GFIS_Springer_Manuscript_Skeleton_v01.tex: Springer Nature LaTeX skeleton
- sn-bibliography.bib: starter BibTeX file
- figures/: generated architecture and workflow diagrams

Important: Numerical results are marked TBD because the experiments have not yet been executed. Do not submit the manuscript to a journal until all TBD values are replaced with verified results and the authorship/declarations are approved by all authors.
